import React, { Component } from "react";
import "./style.css";
import "./index.css"


class FinalList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      items: [],
      searchText: [],
      tempitems: [],
      searchBy: "name"
      
    };
  }



  componentDidMount(){

      fetch('https://user-backendcode.herokuapp.com/getUsers')
      .then(res => res.json())
      .then(json =>{
        this.setState({
          isLoaded: true,
          items: json.data,
          tempitems: json.data
          
        })
      })
  }
  filterSearch = (text) =>{
    return this.state.items.filter((item, index)=>{
      return item[this.state.searchBy].toLowerCase().includes(text);
    })
  }

  onSearchChange = async (e) => {
    var text = e.target.value.toLowerCase().trim();
    this.setState({
      ...this.state,
      tempitems:this.filterSearch(text)
    })
    
  };
  render() {
    
    const { tempitems } = this.state;
    
    return(
      <div className = "container">
        <div className="list-container">
            <input
              name = "searchText"
              
              onChange={this.onSearchChange}
              type="text"
              placeholder="Search User"
              className="search-input"
            />
            <div className="search-list">
              {tempitems &&
                tempitems.map((item, index) => {
                  return (
                    <div className="list-item2" key={index}>
                      <div className="list-item-left">
                        <div className="item">
                          <div className="title">Name</div>
                          <div className="value">{item.name}</div>
                        </div>
                        <div className="item">
                          <div className="title">Age</div>
                          <div className="value">{item.age}</div>
                        </div>
                      </div>
                      <div className="list-item-right">
                        <div className="item">
                          <div className="title">DOB</div>
                          <div className="value">{item.dob}</div>
                        </div>
                        <div className="item">
                          <div className="title">Profession</div>
                          <div className="value">{item.profession}</div>
                        </div>
                      </div>
                      <div className="list-item-right">
                        <div className="item">
                          <div className="title">Number of Guests</div>
                          <div className="value">{item.number_of_guest}</div>
                        </div>
                        <div className="item">
                          <div className="title">Locality</div>
                          <div className="value">{item.locality}</div>
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
      </div>
      
    )
  }
}

export default FinalList;