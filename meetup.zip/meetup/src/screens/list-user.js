import React, { Component } from "react";
import "./style.css";
// import "./index.css"
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
} from "react-router-dom";
import FinalList from "./final-list";

class ListUser extends Component {
  constructor(props) {
    super(props);
    this.state = {
      items: [],
      searchText: [],
      tempitems: [],
      searchBy: "name"
      
     
    };
  }



  componentDidMount(){

      fetch('https://user-backendcode.herokuapp.com/getUsers')
      .then(res => res.json())
      .then(json =>{
        console.log(json.data);
        this.setState({
          isLoaded: true,
          items: json.data,
          tempitems: json.data
          
          
        })
      })
  }
  filterSearch = (text) =>{
    return this.state.items.filter((item, index)=>{
      return item[this.state.searchBy].toLowerCase().includes(text);
    })
  }

  onSearchChange = (e) => {
    var text = e.target.value.toLowerCase().trim();
    this.setState({
      ...this.state,
      tempitems:this.filterSearch(text)
    })
  };

  view = (item) => {
    localStorage.setItem("user",item);  
  }

  render() {

    const { tempitems } = this.state;

    return(
      <Router>
        <div className = "container">
        <div className="list-container">
            <input
              name = "searchText"
              
              onChange={this.onSearchChange}
              type="text"
              placeholder="Search User"
              className="search-input"
            />
            <div className="search-list">
              {tempitems &&
                tempitems.map((item, index) => {
                  return (
                    <div className="list-item" key={index}>
                      <div className="list-item-left">
                      <Link to="/usersDetails">
                      <div className="item">
                          <div className="title">Name</div>
                          <div className="value">{item.name}</div>
                        </div>
                        <div className="item">
                          <div className="title">Locality</div>
                          <div className="value">{item.locality}</div>
                        </div>
                      </Link>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
      </div>
    
            <Switch>
                <Route exact path="/usersDetails">
                  <FinalList />
                </Route>

            </Switch>
           
          </Router>
          // </div>

      
    )
  }
}

export default ListUser;