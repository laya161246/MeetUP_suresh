import React, { Component } from "react";
import "./style.css";
// import "./index.css"
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
} from "react-router-dom";
import FinalList from "./final-list";

class ListUser extends Component {
  constructor(props) {
    super(props);
    this.state = {
      items: [],
     
    };
  }



  componentDidMount(){

      fetch('https://user-backendcode.herokuapp.com/getUsers')
      .then(res => res.json())
      .then(json =>{
        console.log(json.data);
        this.setState({
          isLoaded: true,
          items: json.data,
          masterUsers: [],
          
          
        })
      })
  }

  onSearchChange = async (e) => {
    await this.setState({ searchText: e.target.value });
    const { searchText, masterUsers } = this.state;
    if (searchText) {
      let filteredUsers = masterUsers.filter(
        (item) => item.name.toLowerCase().indexOf(searchText.toLowerCase()) > -1
      );

      if (filteredUsers && filteredUsers.length !== 0) {
        await this.setState({ users: filteredUsers });
      }
    } else {
      await this.setState({ users: masterUsers });
    }
  };

  view = (item) => {
    localStorage.setItem("user",item);  
  }

  render() {

    const { items, searchText } = this.state;
    const{data} = items
    console.log(data)
    return(
      <Router>
      <div className = "container">
        <div className="list-container">
            <input
              value={searchText}
              onChange={this.onSearchChange}
              type="text"
              placeholder="Search User"
              className="search-input"
            />
            <table className="bg">
              <thead >
                <tr className="table">
                  <th>Name</th>
                  <th>Locality</th>
                </tr>
              </thead>
              <tbody>
              {this.state.items &&
                this.state.items.map((item, index) => {
                  console.log(item);
                    return (
                      
                        <tr  key={index} onClick={(item)=> this.view(item)}>

                        <Link to="/usersDetails">{item.name}</Link>
                        <br></br>
                          <td>{item.locality}</td>
                        </tr>

                     
                      
                      
                
                    );
                  })}
              </tbody>

            </table>
             </div>
            </div>
            <Switch>
                <Route exact path="/usersDetails">
                  <FinalList />
                </Route>

            </Switch>
           
          </Router>
          // </div>

      
    )
  }
}

export default ListUser;