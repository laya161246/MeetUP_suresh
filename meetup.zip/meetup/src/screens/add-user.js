import React, { Component } from "react";
import "./style.css";
import moment from "moment";
class AddUser extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "",
      age: "",
      dob: "",
      locality: "",
      address: "",
      numberOfGuest: "",
      profession: "",
    };
  }

  changeHandler = (e) => {
    this.setState({[e.target.name]: e.target.value})
    console.log(e.target.value)
  }

  onAddParticipant = e =>{
    e.preventDefault()
    
    console.log("Adding")
  fetch (`https://user-backendcode.herokuapp.com/addUser`, {
              method: 'post',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify ({
                name : this.state.username,
                age:this.state.age,
                dob:this.state.dob,
                profession:this.state.profession,
                locality:this.state.locality,
                noOfGuests:this.state.numberOfGuest,
                address:this.state.address
              }),
            })
              .then (res => {
                if (res.status === 200) {
                  console.log("Inserted");
                  alert('You are registered');
                } else if (res.status === 400) {
                  alert("Error in Registering");
                  console.log("Error in inserting");
                }
              })
              .catch (err => {
                console.log (err);
              });

  }
  render() {
    const {
      username,
      age,
      address,
      locality,
      profession,
      dob,
      numberOfGuest,
    } = this.state;
    let maxDate = moment().subtract(20, "years").calendar();
    maxDate = moment(maxDate).format("YYYY-MM-DD");

    return (
      
      <div className="container">
        <div className="add-user-container">
        <form onSubmit={this.onAddParticipant} className="add-user-form">
            <h2>RSVP</h2>

            <div className="input-container">
              <label className="input-label">* Name</label>
              <input
                required
                value={username}
                name = "username"
                onChange={this.changeHandler}
                className="input-text"
                placeholder="Write your name here"
                type="text"
              />
            </div>
            <div className="input-container">
              <label className="input-label">* Age</label>
              <input
                required
                value={age}
                name = "age"
                onChange={this.changeHandler}
                className="input-text"
                placeholder="Your age "
                type="number"
                min="13"
                max="100"
              />
            </div>
            <div className="input-container">
              <label className="input-label">* DOB</label>
              <input
                required
                value={dob}
                name = "dob"
                onChange={this.changeHandler}
                className="input-text"
                placeholder="Your date of birth"
                type="date"
                min="1900-01-01"
                max={maxDate}
              />
            </div>
            <div className="input-container">
              <label className="input-label">* Profession</label>
              <select
                required
                value={profession}
                name = "profession"
                onChange={this.changeHandler}
              >
                <option value="Employee">Employee</option>
                <option value="student">Student</option>
              </select>
            </div>
            <div className="input-container">
              <label className="input-label">* Locality</label>
              <input
                required
                value={locality}
                name="locality"
                onChange={this.changeHandler}
                className="input-text"
                placeholder="Your locality"
                type="text"
              />
            </div>
            <div className="input-container">
              <label className="input-label">
                * Number of Guests (between 0-2)
              </label>
              <input
                required
                value={numberOfGuest}
                name="numberOfGuest"
                onChange={this.changeHandler}
                className="input-text"
                placeholder="Number of Guests (between 0-2)"
                type="number"
                min="0"
                max="2"
              />
            </div>
            <div className="input-container">
              <label className="input-label">
                * Address (max 50 characters)
              </label>
              <textarea
                required
                value={address}
                name="address"
                onChange={this.changeHandler}
                style={{ resize: "none" }}
                placeholder="Your address (max 50 characters)"
              ></textarea>
            </div>
            <div className="input-container">
              <button className="register-button" type="submit">
                Register
              </button>
            </div>
          </form>
         
        </div>
      </div>
    );
  }
}
export default AddUser;
