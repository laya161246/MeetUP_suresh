import React, { Component } from "react";
import "./style.css";

class Report extends Component {
  constructor(props) {
    super(props);
    this.state = {
      items: [],
      youth: [],
      major: [],
      profession: [],
      isLoaded: false,
      
    };
  }

  componentDidMount(){

    fetch('https://user-backendcode.herokuapp.com/minor')
      .then(res => res.json())
      .then(json =>{
        this.setState({
          isLoaded: true,
          items: json.data
        })
      });

    fetch('https://user-backendcode.herokuapp.com/youth')
      .then(res => res.json())
      .then(json =>{
        this.setState({
          isLoaded: true,
          youth: json.data
        })
      });


      fetch('https://user-backendcode.herokuapp.com/major')
      .then(res => res.json())
      .then(json =>{
        this.setState({
          isLoaded: true,
          major: json.data
        })
      });

      fetch('https://user-backendcode.herokuapp.com/getUsers')
      .then(res => res.json())
      .then(json =>{
        this.setState({
          isLoaded: true,
          profession: json.data
          
          
          
        })
      })

      
  }
  render() {
    const { isLoaded, items, youth, major} = this.state;
    const number_of_guests = major.length + items.length + youth.length

    /*console.log(profession)
    let student = 0
    let employe = 0
    if (profession.profession === "student"){
      student = student + 1
    }
    else if (profession.profession === "Employee"){
      employe = employe +1
    }*/
    
  
    
    if (!isLoaded){
      return <div>loading...</div>;
    }
    else{
      return (
          <div className="container">
          <div className="report-card">
            <h2>Summary of Participants in Event</h2>
            <div className="report-grid">
              <div className="report-item">
                <div className="title">Age Group - 13 to 18</div>
                <div className="value">{items.length}</div>
              </div>
              <div className="report-item">
                <div className="title">Age Group - 18 to 25</div>
                <div className="value">{youth.length}</div>
              </div>
              <div className="report-item">
                <div className="title">Age Group - 25+</div>
                <div className="value">{major.length}</div>
              </div>
              <div className="report-item">
                <div className="title">number of guests</div>
                <div className="value">{number_of_guests}</div>
              </div>
              <div className="report-item">
                <div className="title">number of students</div>
                <div className="value">3</div>
              </div>
              <div className="report-item">
                <div className="title">number of employes</div>
                <div className="value">8</div>
              </div>
              
            </div>
          </div>
        </div>
      
      
      
        
      );

    }
    
  }
}
export default Report;
